from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from .models import UserProfile
from .serializers import UserProfileSerializer

@api_view(['POST'])
def register(request):
    name = request.data.get('name')
    email = request.data.get('email')
    mobile = request.data.get('mobile')
    password = request.data.get('password')

    if email and password and name and mobile:
        try:
            user = User.objects.create_user(username=email, password=password, email=email)
            UserProfile.objects.create(user=user, name=name, mobile=mobile)
            return Response({'message': 'User registered successfully'}, status=status.HTTP_201_CREATED)
        except:
            return Response({'error': 'Already exist'}, status=status.HTTP_400_BAD_REQUEST)
    return Response({'error': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def login_user(request):
    email = request.data.get('email')
    password = request.data.get('password')

    print(email)

    try:
        user = User.objects.get(username=email)
    except:
        return Response({'error': 'User does not exist!'}, status=status.HTTP_400_BAD_REQUEST)

    user = authenticate(request, username=email, password=password)

    if user is not None:
        # login(request, user)
        return Response({'message': 'Success'}, status=status.HTTP_200_OK)
    else:            
        return Response({'error': 'Username or Password does not match!'}, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['GET'])
def get_all_user_profiles(request):
    try:
        user_profiles = UserProfile.objects.select_related('user').all()
        serializer = UserProfileSerializer(user_profiles, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
