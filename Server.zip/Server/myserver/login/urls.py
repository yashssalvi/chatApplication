from django.urls import path
from .views import register, login_user, get_all_user_profiles

urlpatterns = [
    path('register/', register, name='register'),
    path('login/', login_user, name='login_user'),

    path('user-profiles/', get_all_user_profiles, name='get_all_user_profiles'),
]
