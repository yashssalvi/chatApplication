from django.urls import path
from .views import send_Request,get_all_user_requests,update_Status, send_Message, send_Message1
urlpatterns = [
    path('sendRequest/', send_Request, name='send_Request'),
    path('getAllRequest/<str:username>/', get_all_user_requests, name='get_all_user_requests'),
    path('updateStatus/', update_Status, name='update_Status'),
    path('sendMessage/', send_Message, name='send_Message'),
    path('sendMessage1/', send_Message1, name='send_Message1'),
]
