from django.db import models
from django.utils import timezone
import datetime

class Requests(models.Model):
    sender = models.CharField(max_length=255)
    receiver = models.CharField(max_length=255)
    status = models.CharField(max_length=50)

    def __str__(self):
        return f"Request from {self.sender} to {self.receiver}"
    
class ChatsTable(models.Model):
    sender = models.CharField(max_length=255)
    receiver = models.CharField(max_length=255)
    message = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now() + datetime.timedelta(hours=5.5))

    def __str__(self):
        return f"Message for {self.receiver}"
    
    def to_dict(self):
        return {
            "sender": self.sender,
            "receiver": self.receiver,
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
        }
    