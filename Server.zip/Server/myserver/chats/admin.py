from django.contrib import admin

# Register your models here.
from .models import Requests, ChatsTable

admin.site.register(Requests)
admin.site.register(ChatsTable)