# serializers.py
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Requests
from login.models import UserProfile

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['id', 'name']

class RequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Requests
        fields = ['sender', 'receiver', 'status']

class CombinedSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    sender = serializers.CharField()
    receiver = serializers.CharField()
    status = serializers.CharField()

    def to_representation(self, instance):
        user_profile = UserProfile.objects.get(user=instance)
        request = Requests.objects.get(receiver=user_profile.name)

        return {
            'id': instance.id,
            'name': user_profile.name,
            'sender': request.sender,
            'receiver': request.receiver,
            'status': request.status,
        }
