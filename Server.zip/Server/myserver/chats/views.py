from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .models import Requests, ChatsTable
from login.models import User, UserProfile
from django.http import JsonResponse

@api_view(['POST'])
def send_Request(request):
    sender = request.data.get('sender')
    receiver = request.data.get('receiver')
    
    existing_request = Requests.objects.filter(sender = sender, receiver = receiver).first()

    if existing_request:
        return Response({'message': 'Request already exists'}, status=status.HTTP_200_OK)
    else:
        new_request = Requests.objects.create(sender=sender, receiver=receiver, status="Pending")
        return Response({'message': 'Request send successfully'}, status=status.HTTP_201_CREATED)
    
@api_view(['GET'])
def get_all_user_requests(request,username):
    
    combined_data = []
    try:
        requests = Requests.objects.filter(receiver=username)
    except Requests.DoesNotExist:
        return Response([], status=status.HTTP_200_OK)

    for request in requests:
        user = User.objects.get(username = request.sender)
        user_profile = UserProfile.objects.get(user=user)

        combined_data.append({
            'id': user.id,
            'name': user_profile.name,
            'sender': request.sender,
            'receiver': request.receiver,
            'status': request.status,
        })
        
    # print(combined_data)
    return Response(combined_data, status=status.HTTP_200_OK)

@api_view(['POST'])
def update_Status(request):
    sender = request.data.get('sender')
    receiver = request.data.get('receiver')
    status1 = request.data.get('status')
    
    existing_request = Requests.objects.filter(sender = sender, receiver = receiver).first()
    if existing_request:
        existing_request.status = status1
        existing_request.save()

    existing_request1 = Requests.objects.filter(sender = receiver, receiver = sender).first()
    if existing_request1:
        existing_request1.status = status1
        existing_request1.save()

    return Response({'message': 'Status updated'}, status=status.HTTP_200_OK)

def get_conversation(sender, receiver):

    messages = ChatsTable.objects.filter(
        sender=sender, receiver=receiver
    ).union(
        ChatsTable.objects.filter(sender=receiver, receiver=sender)
    ).order_by('timestamp')

    return messages

@api_view(['POST'])
def send_Message(request):
    sender = request.data.get('sender')
    receiver = request.data.get('receiver')
    messageText = request.data.get('messageText')

    new_request = ChatsTable.objects.create(sender=sender, receiver=receiver, message=messageText)

    messages = get_conversation(sender, receiver)
    messages_data = [message.to_dict() for message in messages]
    return JsonResponse(messages_data, safe=False)

@api_view(['POST'])
def send_Message1(request):
    sender = request.data.get('sender')
    receiver = request.data.get('receiver')

    messages = get_conversation(sender, receiver)
    messages_data = [message.to_dict() for message in messages]
    return JsonResponse(messages_data, safe=False)

