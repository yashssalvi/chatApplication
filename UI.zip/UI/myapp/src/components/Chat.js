import React, { useState, useEffect } from 'react';
import '../Chat.css';
import UserList from './UserList';
import ChatWindow from './ChatWindow';
import axios from 'axios';
import { ipofserver } from '../global';

function App() {

  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messages, setMessages] = useState([]);

  const fetchRequest = async () => {
    try {
      const response = await axios.get(ipofserver + 'chatapi/getAllRequest/' + localStorage.getItem('LoginUsername'));
      setUsers(response.data);
      if (response.data.length > 0) {
        setSelectedUser(response.data[0]);
  
        var sender = localStorage.getItem('LoginUsername');
        var receiver = response.data[0].sender;
        try {
          const response = await axios.post(ipofserver + 'chatapi/sendMessage1/', { sender, receiver });
          const originalData = response.data;
          const transformedData = originalData.map(item => ({
            sender: item.sender, // Adjust sender names as required
            text: item.message
          }));
          setMessages(transformedData); // Ensure transformedData is an array
        } catch (error) {
          alert(error.response?.data?.error || 'An error occurred');
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchRequest();
  }, []);


  const handleSendMessage = async (messageText) => {
    var sender = localStorage.getItem('LoginUsername');
    var receiver = selectedUser.sender;
    try {
      const response = await axios.post(ipofserver + 'chatapi/sendMessage/', { sender, receiver, messageText });
      const originalData = response.data;
      const transformedData = originalData.map(item => ({
        sender: item.sender, // Adjust sender names as required
        text: item.message
      }));
      console.log(transformedData);
      setMessages(transformedData); // Ensure transformedData is an array
    } catch (error) {
      alert(error.response?.data?.error || 'An error occurred');
    }
  };

  const setSelectedUser1 = async (userId) => {
    // alert(`Accepted user with id ${userId}`);
    setSelectedUser(userId)
    var sender = localStorage.getItem('LoginUsername');
    var receiver = userId.sender;
    try {
      const response = await axios.post(ipofserver + 'chatapi/sendMessage1/', { sender, receiver });
      const originalData = response.data;
      const transformedData = originalData.map(item => ({
        sender: item.sender, // Adjust sender names as required
        text: item.message
      }));
      setMessages(transformedData); // Ensure transformedData is an array
    } catch (error) {
      alert(error.response?.data?.error || 'An error occurred');
    }
  };

  const handleAcceptUser = async (userId) => {
    // alert(`Accepted user with id ${userId}`);
    var sender = userId.sender;
    var receiver = userId.receiver;
    var status = "Accepted";
    try {
      const response = await axios.post(ipofserver + 'chatapi/updateStatus/', { sender, receiver, status });
      alert(response.data.message);
      fetchRequest();
    } catch (error) {
      alert(error.response?.data?.error || 'An error occurred');
    }
  };

  const handleRejectUser = async (userId) => {
    // console.log(userId);
    var sender = userId.sender;
    var receiver = userId.receiver;
    var status = "Rejected";
    try {
      const response = await axios.post(ipofserver + 'chatapi/updateStatus/', { sender, receiver, status });
      alert(response.data.message);
      fetchRequest();
    } catch (error) {
      alert(error.response?.data?.error || 'An error occurred');
    }
  };

  if (!selectedUser) {
    return <div className="App">
      <div className="sidebar">
        <div className="user-list">
          <input
            type="text"
            placeholder="Search users..."
            className="search-bar"
          />
          <div>No data found...</div>
        </div>
      </div>
    </div>;
  }

  return (
    <div className="App">
      <div className="sidebar">
        <UserList
          users={users}
          onSelectUser={setSelectedUser1}
          onAcceptUser={handleAcceptUser}
          onRejectUser={handleRejectUser}
        />
      </div>
      <div className="main">
        <ChatWindow
          user={selectedUser}
          messages={messages}
          onSendMessage={handleSendMessage}
        />
      </div>
    </div>
  );
}

export default App;
