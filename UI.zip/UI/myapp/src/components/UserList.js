import React, { useState } from 'react';
import '../UserList.css';

function UserList({ users, onSelectUser, onAcceptUser, onRejectUser }) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="user-list">
      <input
        type="text"
        placeholder="Search users..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
        className="search-bar"
      />
      {filteredUsers.map(user => (
        <div key={user.id} className="user">
          <div className="user-details">
            <div className="user-initials">
              {user.name.split(' ').map(name => name[0]).join('')}
            </div>
            <div className="user-info">
              <div className="user-name"
                onClick={user.status === 'Accepted' ? () => onSelectUser(user) : undefined}
                style={{ cursor: user.status === 'Accepted' ? 'pointer' : 'default' }}>
                {user.name}
              </div>
              {user.status === 'Rejected' &&
                <div className="user-message">Request rejected</div>
              }
              {user.status === 'Pending' &&
                <div className="user-actions">
                  <button className="accept-btn" onClick={(e) => { onAcceptUser(user); }}>Accept</button>
                  <button className="reject-btn" onClick={(e) => { onRejectUser(user); }}>Reject</button>
                </div>
              }
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default UserList;
