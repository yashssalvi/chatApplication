import React, { useState } from 'react';
import '../ChatWindow.css';

function ChatWindow({ user, messages, onSendMessage }) {
  const [messageText, setMessageText] = useState('');

  const handleSendClick = () => {
    if (messageText.trim()) {
      onSendMessage(messageText);
      setMessageText('');
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSendClick();
    }
  };

  if (user.status != 'Accepted') {
    return <div className="chat-window">
    </div>
  }

  return (
    <div className="chat-window">
      <div className="chat-header">{user.name}</div>
      <div className="chat-messages">
        {messages.map((message, index) => (
          <div key={index} className={`chat-message ${message.sender === localStorage.getItem('LoginUsername') ? 'outgoing' : 'incoming'}`}>
            <div className={`chat-text ${message.sender === localStorage.getItem('LoginUsername') ? 'outgoing' : 'incoming'}`}>
              <div className="chat-sender">{message.sender}</div>
              <div>{message.text}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input
          type="text"
          value={messageText}
          onChange={(e) => setMessageText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type a message"
        />
        <button onClick={handleSendClick}>Send</button>
      </div>
    </div>
  );
}

export default ChatWindow;
