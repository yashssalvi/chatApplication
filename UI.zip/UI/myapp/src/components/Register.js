import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { ipofserver } from '../global';
/*eslint-disable eqeqeq*/
/* eslint-disable */

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');

  function clearInput() {
    setName('')
    setEmail('')
    setMobile('')
    setPassword('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (name == '' || email == '' || mobile == '' || password == '') {
      alert("Please enter all details !")
    }
    else if (mobile.length != 10) {
      alert("Please enter valid mobile number !")
    }
    else if (!filter.test(email)) {
      alert("Please enter valid email !")
    }
    else {
      try {
        const response = await axios.post(ipofserver + 'api/register/', { name, email, mobile, password });
        alert(response.data.message);
        clearInput()
        window.location.href = '/'
      } catch (error) {
        alert(error.response?.data?.error || 'An error occurred');
        clearInput()
      }
    }
  };

  return (
    <div className="container mt-5">
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name:</label>
          <input
            type="text"
            className="form-control"
            id="name"
            value={name}
            placeholder='Enter name'
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input
            type="text"
            className="form-control"
            id="email"
            value={email}
            placeholder='Enter email'
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="mobile" className="form-label">Mobile no:</label>
          <input
            type="number"
            className="form-control"
            id="mobile"
            value={mobile}
            placeholder='Enter mobile'
            onChange={(e) => setMobile(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password:</label>
          <input
            type="password"
            className="form-control"
            id="password"
            value={password}
            placeholder='Enter password'
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
    </div>
  );
};

export default Register;
