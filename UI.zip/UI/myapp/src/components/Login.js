import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { ipofserver } from '../global';
import { useNavigate } from 'react-router-dom';
/*eslint-disable eqeqeq*/
/* eslint-disable */

const Login = ({ setIsLoggedIn }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (email == '' || password == '') {
      alert("Please enter all details !")
    }
    else {
      try {
        const response = await axios.post(ipofserver + 'api/login/', { email, password });
        if (response.data.message == 'Success') {
          setIsLoggedIn(true);
          localStorage.setItem('LoginUsername', email);
          navigate('/chat');
        }
        else {
          alert('An error occurred');
        }
      } catch (error) {
        alert(error.response?.data?.error || 'An error occurred');
      }
    }
  };

  return (
    <div className="container mt-5">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email:</label>
          <input
            type="text"
            className="form-control"
            id="email"
            value={email}
            placeholder='Enter email'
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password:</label>
          <input
            type="password"
            className="form-control"
            id="password"
            value={password}
            placeholder='Enter password'
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
    </div>
  );
};

export default Login;
