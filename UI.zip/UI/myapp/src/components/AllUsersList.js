import React, { useEffect, useState } from 'react';
import '../AllUsersList.css';
import axios from 'axios';
import { ipofserver } from '../global';

function AllUsersList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setAllUsers] = useState([]);

  useEffect(() => {
    const fetchProfiles = async () => {
      try {
        const response = await axios.get(ipofserver + 'api/user-profiles/');
        const filteredProfiles = response.data.filter(profile => profile.username !== localStorage.getItem('LoginUsername'));
        // console.log(filteredProfiles);
        setAllUsers(filteredProfiles);
      } catch (err) {
        console.error(err);
      }
    };

    fetchProfiles();
  }, []);

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const onSendRequest = async (userName) => {
    var sender = localStorage.getItem('LoginUsername');
    var receiver = userName;
    try {
      const response = await axios.post(ipofserver + 'chatapi/sendRequest/', { sender, receiver });
      alert(response.data.message);
    } catch (error) {
      alert(error.response?.data?.error || 'An error occurred');
    }
  };

  return (
    <div className="all-users-list">
      <input
        type="text"
        placeholder="Search users..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
        className="search-bar"
      />
      {filteredUsers.map(user => (
        <div key={user.id} className="user">
          <div className="user-details">
            <div className="user-initials">
              {user.name.split(' ').map(name => name[0]).join('')}
            </div>
            <div className="user-info">
              <div className="user-name">{user.name}</div>
              <button className="send-request-btn" onClick={() => onSendRequest(user.username)}>Send Request</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default AllUsersList;
