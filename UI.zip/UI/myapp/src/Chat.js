import React, { useState } from 'react';
import '../Chat.css';
import UserList from './UserList';
import ChatWindow from './ChatWindow';

const users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
  { id: 3, name: 'Charlie' },
];

function App() {
  const [selectedUser, setSelectedUser] = useState(users[0]);
  const [messages, setMessages] = useState({
    1: [
      { sender: 'Alice', text: 'Hello!' },
      { sender: 'You', text: 'Hi Alice!' },
    ],
    2: [
      { sender: 'Bob', text: 'Hey there!' },
      { sender: 'You', text: 'Hello Bob!' },
    ],
    3: [
      { sender: 'Charlie', text: 'Good morning!' },
      { sender: 'You', text: 'Good morning Charlie!' },
    ],
  });

  const handleSendMessage = (text) => {
    setMessages((prevMessages) => {
      const newMessages = { ...prevMessages };
      newMessages[selectedUser.id].push({ sender: 'You', text });
      return newMessages;
    });
  };

  const handleAcceptUser = (userId) => {
    // Handle user acceptance logic
    alert(`Accepted user with id ${userId}`);
  };

  const handleRejectUser = (userId) => {
    // Handle user rejection logic
    console.log(`Rejected user with id ${userId}`);
  };

  return (
    <div className="App">
      <div className="sidebar">
        <UserList
          users={users}
          onSelectUser={setSelectedUser}
          onAcceptUser={handleAcceptUser}
          onRejectUser={handleRejectUser}
        />
      </div>
      <div className="main">
        <ChatWindow
          user={selectedUser}
          messages={messages[selectedUser.id]}
          onSendMessage={handleSendMessage}
        />
      </div>
    </div>
  );
}

export default App;
